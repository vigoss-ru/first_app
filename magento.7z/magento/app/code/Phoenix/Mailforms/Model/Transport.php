<?php

/**
 * Created by Phoenix Media
 * http://www.phoenix-media.eu/
 * Date: 13.07.2016
 * Time: 16:18
 */

namespace Phoenix\Mailforms\Model;

use Magento\Framework\App\ResponseInterface;

class Transport extends \Magento\Contact\Controller\Index
{


    /**
     * Dispatch request
     *
     * @return \Magento\Framework\Controller\ResultInterface|ResponseInterface
     * @throws \Magento\Framework\Exception\NotFoundException
     */
    public function execute()
    {
        // TODO: Implement execute() method.
    }
}