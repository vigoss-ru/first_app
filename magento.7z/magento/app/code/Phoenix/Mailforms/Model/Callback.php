<?php
/**
 * Created by Phoenix Media
 * http://www.phoenix-media.eu/
 * Date: 13.07.2016
 * Time: 16:56
 */

namespace Phoenix\Mailforms\Model;


class Callback
{

    private $phone;

    private $name;

    private $subject;

    /**
     * @return mixed
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * @param mixed $phone
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * @param mixed $name
     */
    public function setName($name)
    {
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getSubject()
    {
        return $this->subject;
    }

    /**
     * @param mixed $subject
     */
    public function setSubject($subject)
    {
        $this->subject = $subject;
    }



}