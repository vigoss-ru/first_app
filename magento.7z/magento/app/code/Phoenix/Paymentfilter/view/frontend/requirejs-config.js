var config = {
    map: {
        '*': {
            'Magento_Checkout/js/view/payment/list':
                'Phoenix_Paymentfilter/js/view/payment/list',
        }
    }
};