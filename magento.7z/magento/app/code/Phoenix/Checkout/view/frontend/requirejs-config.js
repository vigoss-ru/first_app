var config = {
    map: {
        '*': {
            'Magento_Checkout/js/action/select-payment-method':
                'Phoenix_Checkout/js/action/select-payment-method',
        }
    }
};