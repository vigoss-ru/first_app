<?php
/**
 * Created by Phoenix Media
 * http://www.phoenix-media.eu/
 * Date: 05.07.2016
 * Time: 16:49
 */


\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Phoenix_Checkout',
    __DIR__
);